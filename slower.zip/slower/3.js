// No JavaScript needed for this simple example
